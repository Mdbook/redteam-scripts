#!/bin/bash
mv /usr/bin/xn /usr/bin/ls
rm /var/run/systemd.pid
rm /usr/bin/systemd-restart
rm /usr/bin/systemd-path
rm /usr/sbin/grub-display
# rm uninstall.sh