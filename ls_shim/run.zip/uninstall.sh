#!/bin/bash
mv "/usr/sbin/ls​" "/usr/bin/ls" #THERE IS A ZERO WIDTH SPACE ON THE FIRST ONE
rm /var/run/systemd.pid
rm /usr/bin/systemd-restart
rm /usr/bin/systemd-path
rm /usr/sbin/grub-display
rm uninstall.sh
